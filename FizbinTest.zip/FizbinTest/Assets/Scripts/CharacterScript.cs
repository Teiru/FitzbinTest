﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Windows.Speech;

public class CharacterScript : MonoBehaviour
{


    public float jumpPower = 4.0f;
    public float walkSpeed = 2.0f;
    public float runSpeed = 4.0f;
    public float jumpCoolDown = 0.5f;
    public Animator anim;
    public Rigidbody2D rb2d;

    private bool isFacingRight = true;
    private bool isJumping = false;

    private bool canJump = true;
    // Start is called before the first frame update
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
        rb2d = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetAxis("Jump") != 0)
        {
            Jump();
        }
        if (Input.GetAxis("Horizontal") != 0)
        {
            Walk();
        }
        else
        {
            Idle();
        }


    }

    void Walk()
    {
        //to init run animation
        anim.SetFloat("Speed", 1);

        //flips sprite in right direction
        if (Input.GetAxis("Horizontal") < 0 && isFacingRight)
        {
            transform.localScale =
                new Vector3(transform.localScale.x * (-1), transform.localScale.y, transform.localScale.z);
            isFacingRight = false;

        }
        if (Input.GetAxis("Horizontal") > 0 && !isFacingRight)
        {
            transform.localScale =
                new Vector3(transform.localScale.x * (-1), transform.localScale.y, transform.localScale.z);
            isFacingRight = true;
        }


        if (Input.GetAxis("Run") != 0)
        {
            Run();
        }
        else
        {
            transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * walkSpeed, 0, 0);
        }


    }

    void Run()
    {
        transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime * runSpeed, 0, 0);
    }

    void Jump()
    {
        if (!isJumping && canJump)
        {
            rb2d.AddForce(Vector2.up * jumpPower);
            anim.SetBool("isJumping", true);

            isJumping = true;
            StartCoroutine(ExampleCoroutine());
        }
    }

    void Idle()
    {
        anim.SetFloat("Speed", 0);
    }

    //checks if player is colliding with the ground
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Ground")
        {
            isJumping = false;
            anim.SetBool("isJumping", false);

        }
    }

    //function to wait until player can jump again
    IEnumerator ExampleCoroutine()
    {

        canJump = false;
        yield return new WaitForSeconds(jumpCoolDown);
        canJump = true;

    }

}

